var class_wi_fi_services =
[
    [ "WiFiServices", "class_wi_fi_services.html#a5eec4b6f6f1b2356f3382510c7f5153c", null ],
    [ "~WiFiServices", "class_wi_fi_services.html#a7f5fe522ff44dab1ec1b270183f89857", null ]
];