var searchData=
[
  ['open_93',['open',['../class_e_s_p___s_d.html#a711c7a7ac7d491e3c3c1a063f48624ab',1,'ESP_SD']]],
  ['opendir_94',['openDir',['../class_e_s_p___s_d.html#a5cbfd0f7a7a913204ce3078893ed912e',1,'ESP_SD']]],
  ['operator_20bool_95',['operator bool',['../class_serial__2___socket.html#aa9a7cb15a5b2a9b4efce3195b41a49ba',1,'Serial_2_Socket']]]
];
